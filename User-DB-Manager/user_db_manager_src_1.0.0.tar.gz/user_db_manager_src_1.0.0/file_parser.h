/*---------------------- Copyright (c) Picarro, 2017 -------------------
 *                                 Source code
 * This software is the property of Picarro and should be considered and treated
 * as proprietary information.  Refer to the "Source Code License Agreement"
 *----------------------------------------------------------------------------
*/

char* get_ch4_ppm_update_db(char *,char * ,char *);
void fill_values(char *date_time,char *user_name, char *,int ,int,int);
void calculate_SD(int);
float stof(const char* s);
